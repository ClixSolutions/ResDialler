<?php

	class pool extends singlepage {

		// Set up our page
		protected function run() {
		
		 
          
		}
		
	}

?>