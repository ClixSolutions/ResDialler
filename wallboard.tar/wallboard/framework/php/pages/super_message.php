<?php

	class super_message extends singlepage {
		


		// Set up our page
		protected function run() {
		
		}
		
	}

?>