<?php

	class p45 extends singlepage {
		


		// Set up our page
		protected function run() {
		
		}
		
	}

?>